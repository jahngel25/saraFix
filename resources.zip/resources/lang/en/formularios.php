<?php

return [

   'name' => 'Nombre',
   'img_foto' => 'Foto profesional',
   'email' => 'Correo electronico',
   'identificacion' => 'Identificación',
   'fecha_nacimiento' => 'Fecha de Nacimiento'


];
