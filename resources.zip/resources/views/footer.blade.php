<footer id="footer2" class="clearfix">
    <div id="footer-widgets">
        <div class="container">
            <div id="footer-wrapper">
                <div class="row">
                    <div class="col-sm-6 col-md-2">
                        <div id="meta-3" class="widget widgetFooter widget_meta">
                            <ul>
                                <li><a href="default.aspx" ><i class="fa fa-home fa-fw"></i> Inicio</a></li>
                                <li><a href="privacy.html" target="_blank"><i class="fa fa-link fa-fw"></i> Privacidad</a></li>
                                <li><a href="terminos.html" target="_blank"><i class="fa fa-lock fa-fw"></i> Términos</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-2">
                        <div id="recent-posts-3" >
                            <ul>
                                <li><a href="#" target="_blank"><i class="fa fa-facebook"></i>  Facebook</a></li>
                                <li><a href="#" target="_blank"><i class="fa fa-twitter"></i> Twitter</a></li>
                                <li><a href="#" target="_blank"><i class="fa fa-youtube"></i> Youtube</a></li>
                                <li><a href="tel:3057721582"><strong><i class="fa fa-whatsapp"> </i>  305-772-1582 </strong></a> </li>
                                <li><a href="tel:0313061720"><strong> <i class="fa fa-phone"> </i>   3-06-17-20</strong></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div id="search-3">
                            <div class="form-group">
                                <div id="meta3-4" class="widget widgetFooter widget_meta">
                                    <ul>
                                        <li><a href="jobs.aspx" target="_blank"><i class="fa fa-briefcase fa-fw"></i> Trabaja con nosotros</a></li>
                                        <li><a href="faq.htm" target="_blank"><i class="fa fa-comment fa-fw"></i> Preguntas frecuentes</a></li>
                                        <li><a href="signup.aspx"><i class="fa fa-user fa-fw"></i> Ingresa a tu cuenta</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="sub-floor">
        <div class="container">
            <div class="row">
                <div class="col-md-4 copyright">
                    Todos los derechos reservados © 2019 Bogotá - Colombia
                </div>
                <div class="col-md-4 col-md-offset-4 attribution">
                    <b>Desarrollado por:</b>  Juan Daniel Angel Franco
                    <br>
                    Arley Antonio Cabrera Mendoza
                    <br>
                    Diego Sanchez
                </div>
            </div>
        </div>
    </div>
</footer>