<h1>Page no found</h1>
<INPUT type="button" value="Volver" onClick="history.back()">