<li><a href="{{ route('usuarioCliente') }}">Usuario Cliente</a></li>
<li><a href="{{ route('usuarioConstructor') }}">Usuario Constructor</a></li>
<li><a href="{{ route('area') }}">Areas</a></li>
<li><a href="{{ route('servicioList') }}">Servicio</a></li>
<li><a href="{{ route('contactenosAdmin') }}">Contactenos</a></li>
<li><a href="{{ route('cotizacionesAdmin') }}">Cotizaciones</a></li>