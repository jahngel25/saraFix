<li><a href="{{route('compras')}}">Historico de compras</a></li>
<li><a href="{{route('homeCliente')}}">Realizar Pagos</a></li>
