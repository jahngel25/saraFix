<?php

return [

    '1' => 'Creado',
    '2' => 'Pago',
    '3' => 'En proceso',
    '4' => 'Terminado'

];