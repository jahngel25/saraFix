<?php

return [

    'name' => 'Nombre',
    'img_foto' => 'Foto profesional',
    'email' => 'Correo electronico',
    'identificacion' => 'Identificación',
    'fecha_nacimiento' => 'Fecha de Nacimiento',
    'direccion' => 'Direccion',
    'transporte' => 'Transporte',
    'documento_doc' => 'Documento Identidad',
    'certificado_doc' => 'Certificados',
    'bachiller_doc' => 'Acta  Bachiller',
    'eps_doc' => 'Certificado EPS',
    'experiencia' => 'Años de experiencia',
    'perfil' => 'Pefil'


];
