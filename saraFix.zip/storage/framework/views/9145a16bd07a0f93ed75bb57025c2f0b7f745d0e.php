<li><a href="<?php echo e(route('usuarioCliente')); ?>">Usuario Cliente</a></li>
<li><a href="<?php echo e(route('usuarioConstructor')); ?>">Usuario Constructor</a></li>
<li><a href="<?php echo e(route('area')); ?>">Areas</a></li>
<li><a href="<?php echo e(route('servicioList')); ?>">Servicio</a></li>
<li><a href="<?php echo e(route('contactenosAdmin')); ?>">Contactenos</a></li>
<li><a href="<?php echo e(route('cotizacionesAdmin')); ?>">Cotizaciones</a></li>
<li><a href="<?php echo e(route('solicitudRetiros')); ?>">Retiros</a></li>