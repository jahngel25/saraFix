<?php $__env->startSection('contentStyles'); ?>
    <style>
        select{
            background-color: rgba(255, 255, 255, 0.9);
            width: 32%;
            padding: 5px;
            border: 1px solid #DEE047;
            border-radius: 2px;
            height: 2rem;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 3%">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading" style="text-align: center">
                        <h3><b>Contactenos</b></h3>
                    </div>
                    <div class="row" style="margin-top: 2%">
                        <div class="col-md-1"></div>
                        <div class="col-md-10">
                            <table id="tableContactenos" class="display dataTable">
                                <thead>
                                <tr>
                                    <th><b>Nombre</b></th>
                                    <th><b>Email</b></th>
                                    <th><b>Telefono</b></th>
                                    <th><b>Mensaje</b></th>
                                    <th><b>Responder</b></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $modelContactenos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($value->name); ?></td>
                                        <td><?php echo e($value->email); ?></td>
                                        <td><?php echo e($value->telefono); ?></td>
                                        <td><?php echo e($value->mensaje); ?></td>
                                        <td style="text-align: center">
                                            <a href="" data-toggle="modal" data-target="#exampleModal">
                                                <i class="fa fa-check-circle fa-2x iconColor" aria-hidden="true" onclick="valueInput('<?php echo e($value->email); ?>','<?php echo e($value->name); ?>')"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-1"></div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="exampleModal" style="background-color: transparent" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <h3 class="modal-title textAlingCenter" id="exampleModalLabel">Responder inquietud.</h3>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('emailContactenos')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <div class="form-group<?php echo e($errors->has('respuesta') ? ' has-error' : ''); ?>">
                                        <label for="respuesta" class="col-md-4 control-label">Respuesta</label>
                                        <div class="col-md-12">
                                            <textarea name="respuesta" id="respuesta" cols="30" rows="30" style="height: 6rem;"></textarea>
                                            <?php if($errors->has('respuesta')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('respuesta')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <input type="hidden" name="email" id="email">
                                    <input type="hidden" name="name" id="name">
                                </div>
                                <div class="modal-footer">
                                    <input type="submit" class="btn btn-primary" value="Responder">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentScript'); ?>
    <script>
        function valueInput(email, name)
        {
            $('#email').val(email);
            $('#name').val(name);
        }
        $(document).ready( function () {
            $('#tableContactenos').DataTable({
                pageLength: 5,
                language: {
                    "sProcessing":     "Procesando...",
                    "sLengthMenu":     "Mostrar _MENU_ registros",
                    "sZeroRecords":    "No se encontraron resultados",
                    "sEmptyTable":     "Ningún dato disponible en esta tabla",
                    "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                    "sInfoPostFix":    "",
                    "sSearch":         "Buscar:",
                    "sUrl":            "",
                    "sInfoThousands":  ",",
                    "sLoadingRecords": "Cargando...",
                    "oPaginate": {
                        "sFirst":    "Primero",
                        "sLast":     "Último",
                        "sNext":     "Siguiente",
                        "sPrevious": "Anterior"
                    },
                    "oAria": {
                        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                    }
                }
            });
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>