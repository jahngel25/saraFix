<?php $__env->startSection('content'); ?>
    <div class="container formRegister" style="margin-top: 5%">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Editar Area</div>
                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('actionEditArea', $modelArea->id)); ?>" files="true" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-md-4 control-label">Area</label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="stylesInput" name="name" value="<?php echo e($modelArea->name); ?>" required autofocus>
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-md-4 control-label">Descripcion</label>

                                <div class="col-md-6">
                                    <input id="description" type="text" class="stylesInput" name="description" value="<?php echo e($modelArea->description); ?>" required autofocus>

                                    <?php if($errors->has('description')): ?>
                                        <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('img') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-md-4 control-label">Imagen servicio</label>

                                <div class="col-md-6">
                                    <input id="img" type="file" class="stylesInput" name="img" value="<?php echo e($modelArea->img); ?>" autofocus>

                                    <?php if($errors->has('img')): ?>
                                        <span class="help-block">
                                    <strong><?php echo e($errors->first('img')); ?></strong>
                                </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('texto') ? ' has-error' : ''); ?>">
                                <label for="texto" class="col-md-4 control-label">Texto</label>

                                <div class="col-md-6">
                                    <input id="texto" type="text" class="stylesInput" name="texto" value="<?php echo e($modelArea->texto); ?>" required autofocus>

                                    <?php if($errors->has('texto')): ?>
                                        <span class="help-block">
                                    <strong><?php echo e($errors->first('texto')); ?></strong>
                                </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('img_inter') ? ' has-error' : ''); ?>">
                                <label for="img_inter" class="col-md-4 control-label">Segunda Imagen</label>

                                <div class="col-md-6">
                                    <input id="img_inter" type="file" class="stylesInput" name="img_inter" value="<?php echo e($modelArea->img_inter); ?>}}" autofocus>

                                    <?php if($errors->has('img_inter')): ?>
                                        <span class="help-block">
                                    <strong><?php echo e($errors->first('img_inter')); ?></strong>
                                </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-warning colorBtn">
                                        Editar
                                    </button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>