<li><a href="<?php echo e(route('realizados')); ?>">Trabajos realizados</a></li>
<li><a href="<?php echo e(route('proceso')); ?>">Trabajos en proceso</a></li>
<li><a href="<?php echo e(route('homeTodero')); ?>">Aceptar trabajo</a></li>
<li><a href="<?php echo e(route('ingresos')); ?>">Tus Ingresos</a></li>
