<?php $__env->startSection('content'); ?>
    <div class="container formRegister" style="margin-top: 10%">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Editar Area</div>
                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('actionEditServicio', $modelServicio->id)); ?>" files="true" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-md-4 control-label">Servicio</label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="stylesInput" name="name" value="<?php echo e($modelServicio->name); ?>" required autofocus>
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-md-4 control-label">Descripcion</label>

                                <div class="col-md-6">
                                    <input id="description" type="text" class="stylesInput" name="description" value="<?php echo e($modelServicio->description); ?>" required autofocus>

                                    <?php if($errors->has('description')): ?>
                                        <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('img') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-md-4 control-label">Imagen servicio</label>

                                <div class="col-md-6">
                                    <input id="img" type="file" class="stylesInput" name="img" value="<?php echo e($modelServicio->img); ?>" autofocus>

                                    <?php if($errors->has('img')): ?>
                                        <span class="help-block">
                                    <strong><?php echo e($errors->first('img')); ?></strong>
                                </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('precio') ? ' has-error' : ''); ?>">
                                <label for="precio" class="col-md-4 control-label">Precio</label>

                                <div class="col-md-6">
                                    <input id="precio" type="text" class="stylesInput" name="precio" value="<?php echo e($modelServicio->precio); ?>" required autofocus>

                                    <?php if($errors->has('precio')): ?>
                                        <span class="help-block">
                                    <strong><?php echo e($errors->first('precio')); ?></strong>
                                </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('id_area') ? ' has-error' : ''); ?>">
                                <label for="id_area" class="col-md-4 control-label">Area</label>

                                <div class="col-md-6">
                                    <select name="id_area" id="id_area" class="stylesInput">
                                        <option value="0">Seleccione</option>
                                        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($values->id); ?>"><?php echo e($values->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('id_area')): ?>
                                        <span class="help-block">
                                    <strong><?php echo e($errors->first('id_area')); ?></strong>
                                </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-warning colorBtn">
                                        Editar
                                    </button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>