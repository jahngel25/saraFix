<?php $__env->startSection('contentStyles'); ?>

    <style>
        .btn-file {
            position: relative;
            overflow: hidden;
        }
        .btn-file input[type=file] {
            position: absolute;
            top: 0;
            right: 0;
            min-width: 100%;
            min-height: 100%;
            font-size: 100px;
            text-align: right;
            filter: alpha(opacity=0);
            opacity: 0;
            outline: none;
            background: white;
            cursor: inherit;
            display: block;
        }

        #img-upload
        {
            width: 25%;
            margin-top: 6%;
            background-repeat: no-repeat;
            background-position: 65%;
            border-radius: 50%;
            background-size: 100% auto;
        }

        .form-group{
            margin-bottom: 0px !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 3%">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading" style="text-align: center">
                        <h5><b>Registro de información adicional del construtor</b></h5>
                    </div>
                    <?php if($dataTodero != ''): ?>
                        <?php echo $__env->make('Todero.informacionEdit', $dataTodero, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php else: ?>
                        <?php echo $__env->make('Todero.informacionCreate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentScript'); ?>
    <script>
        $(document).ready( function() {
            <?php if($dataAreas != ""): ?>
                <?php $__currentLoopData = $dataAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        $("#<?php echo e($value->id_area); ?>").attr("checked", true);
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if($dataTodero != ''): ?>
                $("#id_tipo_documento option[value="+ <?php echo e($dataTodero->id_tipo_documento); ?> +"]").attr("selected",true);
                $("#pais option[value="+ <?php echo e($dataTodero->id_pais); ?> +"]").attr("selected",true);
                $("#departamento option[value="+ <?php echo e($dataTodero->id_departamento); ?> +"]").attr("selected",true);
                $("#id_ciudad option[value="+ <?php echo e($dataTodero->id_ciudad); ?> +"]").attr("selected",true);
            <?php endif; ?>
        });

        $('#datetimepickerInfo').datetimepicker({
            format: "yyyy-mm-dd",
            autoclose: true,
            pickTime: false
        });

        $(document).ready( function() {
            $(document).on('change', '.btn-file :file', function() {
                var input = $(this),
                    label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
                input.trigger('fileselect', [label]);
            });

            $('.btn-file :file').on('fileselect', function(event, label) {

                var input = $(this).parents('.input-group').find(':text'),
                    log = label;

                if( input.length ) {
                    input.val(log);
                } else {
                    if( log ) alert(log);
                }

            });
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function (e) {
                        $('#img-upload').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $("#img_foto").change(function(){
                readURL(this);
            });
        });

        function traerDepartamneto(id)
        {
            var stringDiv = '<?php echo e(route('traerDepartamento', 'parameter')); ?>';
            var result = stringDiv.replace("parameter", id);

            $.ajax({
                type:'GET',
                url: result,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success:function(data){
                    $('#departamento').html('');
                    $('#departamento').append(' <option value="">Seleccione</option>');
                    $.each(data, function( index, value )
                    {
                        $('#departamento').append(' <option value="'+value['id']+'">'+value['description']+'</option>');
                    });
                }
            });
        }

        function traerCiudad(id)
        {
            var stringDiv = '<?php echo e(route('traerCiudad', 'parameter')); ?>';
            var result = stringDiv.replace("parameter", id);

            $.ajax({
                type:'GET',
                url: result,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success:function(data){
                    $('#id_ciudad').html('');
                    $('#id_ciudad').append(' <option value="">Seleccione</option>');
                    $.each(data, function( index, value )
                    {
                        $('#id_ciudad').append(' <option value="'+value['id']+'">'+value['description']+'</option>');
                    });
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>