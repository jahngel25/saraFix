<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>FixContract</title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Kumar+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="<?php echo e(asset('img/contractLogo.png')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/agency.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/redes.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <!-- Styles -->
    <style>
        nav{
            margin: 0px;
            font-weight: bolder;
            font-family: Raleway,sans-serif;
            font-size: 14px;
        }

        .navbar
        {
            margin-bottom: 0px !important;
        }

        .navbar-default .navbar-nav>li>a, .navbar-default .navbar-text {
            color: #777 !important;
        }

    </style>
</head>
<nav class="navbar navbar-default navbar-static-top">
    <div class="container">
        <div class="navbar-header">

            <!-- Collapsed Hamburger -->
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <!-- Branding Image -->
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('img/navLogo.png')); ?>" alt="" style="display: initial !important;">
            </a>
        </div>

        <div class="collapse navbar-collapse" id="app-navbar-collapse">
            <!-- Left Side Of Navbar -->
            <ul class="nav navbar-nav">
                &nbsp;
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="nav navbar-nav navbar-right" style="text-align: center;">
                <!-- Authentication Links -->
                <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                    <li><a href="<?php echo e(route('login')); ?>">Iniciar Sesion</a></li>
                    <li><a href="<?php echo e(url('/register')); ?>">Registrate</a></li>
                    <li><a href="<?php echo e(route('registerProvider')); ?>">Trabaja con nosotros</a></li>
                <?php else: ?>
                    <?php if(roleUser() == 1): ?>
                        <?php echo $__env->make('layouts.menuTodero', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif(roleUser() == 2): ?>
                        <?php echo $__env->make('layouts.menuCliente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif(roleUser() == 3): ?>
                        <?php echo $__env->make('layouts.menuAdministrador', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endif; ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    Cerrar Sesion
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<body>
    <div class="container">
        <header style="background-image:url('/uploads/<?php echo e($dataArea->img_inter); ?>');" class="jumbotron hero-spacer">
            <h2 style="color: #ffffff"><?php echo e($dataArea->name); ?></h2>
            <h3 style="text-transform:none;color: #ffffff;"><?php echo e($dataArea->description); ?></h3>
            <p> </p>
        </header>
        <hr>
        <div class="row">
            <div class="col-lg-12 text-center">
                <p id="servicios" style="font-size: 16px; font-family:Droid Serif, Helvetica Neue, Helvetica, Arial, sans-serif; text-transform: none; font-style: italic;" ><?php echo e($dataArea->texto); ?></p>
            </div><br />
        </div>
        <div class="row text-center" style="margin-right: -15px !important;margin-left: -15px !important;">
            <?php $__currentLoopData = $dataServicio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 hero-feature">
                    <div class="thumbnail">
                        <div>
                            <img src="<?php echo e(asset('uploads/'.$value->img)); ?>" class="img-responsive" id="imgBtn_43" />
                            <div class="caption">
                                <h4><?php echo e($value->name); ?></h4>
                                <b><h4>$<?php echo e($value->precio); ?> Pesos</h4></b>
                                <a href="<?php echo e(route('ordenServicio', [$value->id, uniqid(), $dataArea->id])); ?>"><button  class="btn btn-primary">Contratar</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="container" style="background-color:aliceblue">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h3>¿No encuentras el servicio que necesitas?</h3>
                <button type="button" class="btn btn-primary" style="background-color: #666666 !important;border-color: #fff !important;" data-toggle="modal" data-target="#exampleModal">
                    SOLICITAR PRESUPUESTO
                </button>
            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <h3 class="modal-title textAlingCenter" id="exampleModalLabel">CUÉNTANOS QUE NECESITAS, EL EQUIPO DE FIX-CONTRACT DESPEJARA TODAS TUS DUDAS.</h3>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('crearCotizacion')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                        <label for="name" class="col-md-2 control-label" style="margin-top: 1%;">Nombre</label>
                                        <div class="col-md-10">
                                            <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                                            <?php if($errors->has('name')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                        <label for="email" class="col-md-2 control-label" style="margin-top: 1%;">E-mail</label>
                                        <div class="col-md-10">
                                            <input id="email" type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                            <?php if($errors->has('email')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('telefono') ? ' has-error' : ''); ?>">
                                        <label for="telefono" class="col-md-2 control-label" style="margin-top: 1%;">Telefono</label>
                                        <div class="col-md-10">
                                            <input id="telefono" type="text" class="form-control" name="telefono" value="<?php echo e(old('telefono')); ?>" required autofocus>
                                            <?php if($errors->has('telefono')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('telefono')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('mensaje') ? ' has-error' : ''); ?>">
                                        <label for="mensaje" class="col-md-2 control-label" style="margin-top: 1%;">Comentarios</label>
                                        <div class="col-md-10">
                                            <textarea id="mensaje" class="form-control" name="mensaje" value="<?php echo e(old('mensaje')); ?>" required autofocus></textarea>
                                            <?php if($errors->has('mensaje')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('mensaje')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div  style="text-align: center; color: #31708f;">
                                    "Nota! En pocos minutos un asesor del área técnica se comunicara contigo"
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                    <input type="hidden" name="id" id="id" value="<?php echo e($dataArea->id); ?>">
                                    <input type="submit" class="btn btn-primary" value="SOLICITAR">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('js/todaruVideo.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ScriptMenu.js')); ?>"></script>
</body>
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</html>
