<?php $__env->startSection('contentStyles'); ?>
    <style>
        select{
            background-color: rgba(255, 255, 255, 0.9);
            width: 32%;
            padding: 5px;
            border: 1px solid #DEE047;
            border-radius: 2px;
            height: 2rem;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 3%">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading" style="text-align: center">
                        <h3><b>Registro de información adicional del construtor</b></h3>
                        <div style="text-align: right">
                            <a href="<?php echo e(route('frmCreacionServicio')); ?>"><button type="button" class="btn btn-warning">Crear</button></a>
                        </div>
                    </div>
                    <div class="row" style="margin-top: 2%">
                        <div class="col-md-1"></div>
                        <div class="col-md-10">
                            <table id="tableServicio" class="display dataTable">
                                <thead>
                                <tr>
                                    <th>Area</th>
                                    <th>descripcion</th>
                                    <th>img</th>
                                    <th>Precio</th>
                                    <th>Servicio</th>
                                    <th>Editar</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $modelServicio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($value->name); ?></td>
                                        <td><?php echo e($value->description); ?></td>
                                        <td style="text-align: center"><input type="image"  class="img-responsive" width="100" height="80" src="<?php echo e(asset('uploads/'.$value->img)); ?>"></td>
                                        <td><?php echo e($value->precio); ?></td>
                                        <td><?php echo e($value->areaName); ?></td>
                                        <td style="text-align: center"><a href="<?php echo e(route('servicioEdit', $value->id)); ?>"><i class="fa fa-pencil-square-o iconColor" aria-hidden="true"></i></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-1"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentScript'); ?>
    <script>
        $(document).ready( function () {
            $('#tableServicio').DataTable({
                pageLength: 5,
                language: {
                    "sProcessing":     "Procesando...",
                    "sLengthMenu":     "Mostrar _MENU_ registros",
                    "sZeroRecords":    "No se encontraron resultados",
                    "sEmptyTable":     "Ningún dato disponible en esta tabla",
                    "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                    "sInfoPostFix":    "",
                    "sSearch":         "Buscar:",
                    "sUrl":            "",
                    "sInfoThousands":  ",",
                    "sLoadingRecords": "Cargando...",
                    "oPaginate": {
                        "sFirst":    "Primero",
                        "sLast":     "Último",
                        "sNext":     "Siguiente",
                        "sPrevious": "Anterior"
                    },
                    "oAria": {
                        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                    }
                }
            });
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>