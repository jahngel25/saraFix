<li><a href="<?php echo e(route('compras')); ?>">Historico de compras</a></li>
<li><a href="<?php echo e(route('homeCliente')); ?>">Realizar Pagos</a></li>
